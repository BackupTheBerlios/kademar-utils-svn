|||  - METRIX METAL DREAM  -  |||
|||  ----------------2002  -  |||
||| designed by: Sven Kistner |||
 -------------------------------
. Homepage: http://www.metrix.de


23.09.2001
>> First metrix WINAMP-SKIN

   Hope you like it. This is the first skin
   metrix made for winamp.
   
   ...probably not the last one ;)
   
11.02.2002
>> New Color-Shemes created
>> cbuttons fixed
      

X:) THX for downloading this skin...