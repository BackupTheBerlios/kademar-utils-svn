WINAMP 5 MODERN SKIN PORTED TO CLASSIC FORMAT
---------------------------------------------
16.05.2004

Finally I can pronounce that there will be no more changes of the skin. I would like to thank everyone who was involved in this project, especially wildrose-wally and GuidoD. Usually it�s difficult to get good results when so many people are involved in one project, but in this case I must say we did an excellent job. 

Development team: 

GuidoD [http://www.gfdd.net]

wildrose-wally [http://www.fusionamp.com]

Zarko Jovic [www.zrco.net]

For more details please visit our thread in the Winamp forums.

--------------------------------

Couple of days ago I've installed winamp 5 and amazed by the look of the new skin. Since I am fan of standard winamp 2.9 shape I've decided to redesign Sven's fantastic skin to 2.9 shape. Hope one day he will do an original version.

Original skin Sven Kistner 