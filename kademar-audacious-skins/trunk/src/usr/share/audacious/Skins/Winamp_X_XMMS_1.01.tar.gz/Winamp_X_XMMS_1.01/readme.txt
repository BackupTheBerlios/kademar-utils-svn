 ____________________________________________________________

  Winamp X v1.0 - By DeeLight
 ____________________________________________________________

  I made my first  Winamp X skin.  I was inspired  my the new
  Mac OS8 X Aqua  interface.  Some of the  elements look like
  the OS and others are made custom. All credits  go to Apple
  for makind such an amazing Operating System.
 ____________________________________________________________

  Please make  any comments  or any  suggestion  to make this
  skin look better, by keeping the Aqua interface. To contact
  me, send and e-Mail to deelight@flashmail.com
 ____________________________________________________________

  You can also visit my Missing Features Page at:

    http://missingfeatures.cjb.net/
 ____________________________________________________________